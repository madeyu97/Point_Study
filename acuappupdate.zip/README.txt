經穴 · Acupoint Dojo  — deployment

DEPLOY: drag this ENTIRE "jingxue" folder onto Netlify Drop (app.netlify.com/drop).
Drop the folder, not the loose files. Once live (https) it installs to the home
screen and runs offline.

WHAT'S NEW IN THIS BUILD
  - Home now splits into two tracks: REVISE (cards due) and LEARN (new points,
    introduced study-first in batches).
  - "Characters" is a separate side-game (not part of point study): meaning quiz,
    radical/component breakdowns, stroke-order animation, and which points use each
    character. Its progress is tracked apart from your point mastery.
  - Settings (設, top right): daily goal, new-points-per-session, sound.

NOTES
  - Progress saves to this device (localStorage); per-device, survives offline.
  - Stroke-order animation loads from a CDN on first use (cached afterwards); if
    fully offline before it has cached, the character still shows, just unanimated.
  - Reset progress: Settings, or the footer "reset" link.

PRIORITY / ORDER OF STUDY (this build)
  - Learn introduces points by a curated clinical tier list (1 Essential -> 5
    Peripheral). Within a tier, command/confluent/Yuan/He-Sea points lead. The 48
    Extra points are untiered in the source, so they default to the bottom.
    Each point shows its tier on the study card.
  - Atlas shows a tier chip per point and a star (☆/★) to PIN points you consider
    essential — pinned points jump to the front of Learn. Atlas can sort by priority.
  - Settings: "Learn order" = Clinical priority / By channel / Random.

BACKUP & RESTORE (new)
  Settings (設) -> Backup & restore:
    - Export file / Copy backup : saves ALL progress (schedule, XP, streak, pins,
      settings) to a file or your clipboard. Do this regularly, and before any
      browser/storage maintenance or phone change.
    - Import file / Paste backup : restores from a saved backup (replaces current
      progress on this device).
  This is the only thing that survives a cleared browser. Keep a copy somewhere safe.

CHANNEL MAP & DIFFERENTIATE (new)
  - Channel Map (經): walk each channel node by node in true order; tap a node to
    reveal it; neighbours sit directly above/below. "Quiz this channel" highlights a
    node and you name it.
  - Differentiate (辨): tell apart look-alike points (e.g. the cluster at the medial
    malleolus) and adjacent points on a channel, with a side-by-side compare table.
  These review alongside everything in Revise, but are *introduced* through their own
  modes (so a generic session won't flood you with them).

CLINICAL CASES (rebuilt — five reasoning demands, offline)
  醫案 — pick a reasoning type on entry, or "All":
    - Multi-constraint : find the one point meeting several constraints at once
    - Odd one out      : spot the point that doesn't share the group's role
    - Build a Rx       : multi-select the points of a pairing / category set
    - Justify A vs B    : choose the right point, then the grounds for it (2 steps)
    - Points -> pattern : name the command role a point (or set) embodies
  All exercises are assembled from the point data (roles, channels, Dui Yao) with no
  invented facts. Own spaced track; earns XP/streak; shown on the Clinical Cases tile.
  (An optional AI tutor layer is planned for later.)

LOCATE POINTS (new) + body-diagram status
  取穴 — recall and WRITE where each point sits, then self-grade; pick a channel or
  drill all by clinical priority. Production practice (harder than recognising) and
  shares the same spaced schedule as location recall.

  Body-diagram "mark the point" / "highlight -> name" is NOT built. A dataset scout
  found no open, embeddable atlas mapping all points to 2D coordinates (AcuSim is
  head/neck-only ML data; NIH's TARA atlas is forthcoming; commercial apps are
  proprietary). Faking pixel positions would teach wrong locations, so it is deferred
  until coordinates are authored in-app or an open atlas (TARA) becomes available.

CATEGORIES, RESONANCE & STAGED HONOURS (v19)
  Two new sessions (also in the picker):
    Categories 類穴  - the command-point system drilled both ways: a point's
                       category, and picking the category's member from a set.
                       210 items.
    Region Resonance 應區 - which body region a point commands, and which point
                       answers a region. Bidirectional, built from the Envoy
                       data. 84 items.
    Both feed Revise once studied, but are only introduced in their own modes
    (so a Mixed session won't flood you with them).
  Honours rebuilt: 55 now, in five stages (Novice / Apprentice / Journeyman /
    Physician / Master). Each stage holds several sections - Practice,
    Consistency, Ground, Craft, Channels, Categories - so there is always a
    near milestone even though the whole arc is long. One honour per channel
    (15) and one per command category (10). Collapsed on the home screen;
    tap "Honours" to open.
  Fixed: session titles rendered in the browser's default black on the dark
    cards (the button had no colour set). Same latent issue fixed on .btn.

UNIFIED SESSIONS + IN-SESSION EDITING (v20)
  Home screen is now three choices instead of ten:
    Balanced Practice 均習 - a little of everything, weighted to names/locations
    Clinical Focus    臨習 - weighted to functions, categories, resonance,
                             differentiation and multi-step cases
    Review Only       復習 - just what is due, nothing new
  Both weighted sessions draw from ONE pool covering every drill type (point
  cards, location, channel map, categories, resonance, function, command
  matrix, clinical reasoning, envoys, dui yao, safety, differentiate,
  characters, and multi-step clinical cases). Weightings decide the mix.
  Session length: a 5-30 minute slider. A multi-step case counts as ~6 cards.
  Sessions fill with due cards first, then new (scaled to length), then early
  review so the chosen length is honoured.
  "Learn new points" and "Full clinic case" remain as links below; every
  individual drill is still in the collapsed mode library.

  Categories 類穴 now runs all three ways, including the one that matters most
  in clinic: "which point is the Yuan-Source of the Kidney channel?" (111 items).

  Edit a point mid-session: the pencil in the session header opens the editor
  for whatever point the card is about; saving redraws the card at once.

  Channel Map no longer prints the code-number beside each option - the track
  showed the position AND the options showed the number, so it could be solved
  by arithmetic. Options now show pinyin (and English); the answer still teaches
  the code.

FIX (v21) — multi-select cases inside a session
  "Build a Rx" cases (select the Shu-Stream point on each of 3 channels, or the
  two points of a Dui Yao pair) were being resolved by a single tap when they
  appeared inside Balanced/Clinical sessions: the first tap disabled every
  option and revealed the rest. The session runner only had the single-answer
  path; the multi-select path existed solely in the standalone Cases mode.
  Now: tap to select up to N, a counter shows "Select 3, then check - 1/3",
  Check stays disabled until N are chosen, and on check the answer marks
  correct / wrong / missed. Applies to every multi-select card regardless of
  category (Shu Stream, He Sea, Yuan Source, Dui Yao pairs, and the rest).

DATA FIX (v22) — command roles on the wrong point (tone-collision)
  Two command roles had been attached to the wrong point because the original
  import matched by tone-stripped pinyin without checking the channel:
    Shu Stream : was on KI-15 Zhongzhu 中注  -> corrected to SJ-3 Zhongzhu 中渚
    Xi Cleft   : was on GB-32 Zhongdu 中瀆   -> corrected to LR-6 Zhongdu 中都
  KI-15 and GB-32 carry no command role and now show none.
  A full audit re-derived all 111 command-point assignments by matching BOTH
  channel and pinyin (with aliases for "Gall Bladder", and treating Confluent /
  Lower He Sea / vessel Xi-Cleft rows as naming the vessel treated rather than
  the point's own channel). Every other assignment verified correct; these four
  points were the only errors. Envoy, Dui Yao and contraindication data are
  keyed by point code, so they were never affected.

FIX (v23) — Clinical Reasoning showed the wrong worked example
  The "for example" line under the answer was matched to the answer by FIRST
  WORD only, so "Jing River" also matched "Jing Well" (and vice versa) and half
  the time illustrated the wrong category entirely. Now matched on the exact
  canonical category via an explicit map, so the example always demonstrates the
  category that was actually the answer.
  Also: the "on Yin" variants (Shu Stream on Yin, Xi on Yin) now draw their
  example from a Yin channel only, and add the teaching note - that on Yin
  channels the Shu-Stream is also the Yuan-Source, and that Yin-channel
  Xi-Clefts are used for blood disorders and bleeding.
  Bei Shu and Mu correctly show no example (they are not in the naming grid).
  Verified over 1200 generated examples: the example category now always equals
  the answer category.

FIX (v24) — stale day counter and phantom streak
  The day only rolled over inside touchDay(), which runs when you GRADE a card.
  So opening the app after a break showed the last study day's figures: a daily
  count that could read "41 of 30", and a streak that had actually already
  lapsed. Nothing was corrupted - the numbers corrected themselves the moment
  you graded anything - but the home screen was lying until then.
  Now a rollDay() runs whenever the app opens or the home screen renders:
    - the daily counter resets when the date changes
    - a streak that has genuinely lapsed settles to 0 immediately
    - a banked freeze is still only SPENT by actually studying, never by
      merely opening the app
  The streak line now states where you stand:
    studied today      -> "N-day streak - X freezes"
    studied yesterday  -> "N-day streak - study today to keep it"
    missed, freeze held-> "N-day streak - a freeze will cover yesterday"
    lapsed             -> "no streak yet - study today to start one"

ARCHIVE A CARD (v25)
  During any session, the ⊘ button in the header archives the card you are
  looking at. It is removed from the session immediately and never appears
  again - in any mode, count, or generated session - until restored.
  Settings -> Archived cards lists them with readable labels
  ("Location · Hegu LI-4") and restores them one at a time or all at once.
  The card's review history is deliberately KEPT while archived, so restoring
  resumes its schedule rather than starting it from scratch.
  Archives ride along in Backup export/import.

COLLEAGUES 同道 (v26) — usernames, connections, shared progress, rivals
  SETUP: run social-schema.sql in Supabase (SQL Editor) once, alongside the
  existing progress table. Requires sync to be configured and signed in.
  - Username: claimed on first visit to Colleagues. 3-20 chars, lowercase
    letters/numbers/underscore. Others add you by USERNAME, never by email.
  - Connections are mutual: a request is pending until the other person
    accepts. Nothing is shared before that, and removing a connection stops
    sharing both ways at once.
  - Shared summary only: streak, level, mature points, honours, reviews this
    week. NEVER your notes, edits, archived cards, which cards you find hard,
    or your email. Enforced by row-level security on the server, not just in
    the app.
  - Star (☆/★) a colleague to make them a "rival": they appear in a strip at
    the top of your home screen with your own row for comparison, refreshed
    when you open the app and cached so it still shows offline. Starring is
    entirely local - nobody is told you starred them.
  - No free-text messaging, by design.

SESSIONS REWORKED + STUDY MATERIAL TOGGLES (v27)
  DAILY GOAL 日課 (new, and now the primary session): takes EVERY due card
    first, then tops up with new cards until your daily goal is reached.
    If more is due than the goal, you get all of it - due work is never
    truncated. Cards already done today count toward the goal.
  TIMED SPRINT 限時 (new, replaces the minutes slider): choose 5/10/15/20/30
    minutes on the home screen; the session runs until the clock expires and
    then reports how far you got. A small muted countdown sits in the session
    header and turns cinnabar in the final minute.
  REMOVED: the session-length slider. It estimated 5 cards per minute, which
    was simply wrong, so the numbers it promised were meaningless.
  STUDY MATERIAL 學材 (Settings): a collapsible section of toggles -
    13 card types, 15 channels, 5 clinical-priority tiers, each with
    all-on/all-off. Channel and tier scope apply everywhere (they define what
    material is in play); card-type toggles apply to the automatic sessions,
    so opening a specific drill from the library still works. The section
    header summarises what is switched off at a glance. Filters ride along in
    backups.

FIX (v28) — Daily Goal now genuinely clears the work
  A card graded "Again" or "Hard" goes back into learning and falls due again
  within a minute or ten. The session queue was built once at the start, so
  those cards were never re-shown - you finished the session with cards still
  due. (A sweep at the end cannot fix this: a card failed seconds ago is due
  in 60 seconds, not now.)
  Now a card graded Again/Hard is re-queued a few cards later and shown again
  before the session ends, capped at 5 showings so a stubborn card cannot loop
  forever. Daily Goal and Review Only additionally sweep once more at the end
  for anything that fell due while you studied (max 4 sweeps). Timed Sprint is
  never extended by a sweep - the clock ends it.
  Also fixed: the Daily Goal budget counted a multi-step clinical case as 6
  cards while the daily counter counted it as 1, so sessions containing cases
  under-delivered against the goal. The goal is now a straight count of cards.

FIX (v28) — multiple-choice option order
  Options were shuffled once when the card was built, so a card seen twice had
  the same layout and the answer could be remembered by position. Options are
  now reshuffled every single time a card is shown.

SIMPLIFIED (v29)
  REMOVED Clinic 臨床 (the full mock case) and its embedded 97-pattern dataset.
    That is 80KB lighter. The Gemini tutor function on Netlify is now unused but
    harmless. Pattern study lives in the separate Pattern Dojo app.
    NOTE: Clinical Reasoning 辨證 and Clinical Cases 醫案 are NOT affected -
    those are point-based drills and remain.
  REMOVED the Clinical Focus session. Balanced Practice covers mixed work.
  PROMOTED Learn New Points to a full session card on the home screen - it was
    buried in a small text link.
  BALANCED PRACTICE size is now yours: chips for 10/20/30/40 cards under the
    card, default 20. It previously built a fixed ~50-60 card session.
  Home screen is now five cards: Daily Goal, Learn New Points, Balanced
  Practice, Review Only, Timed Sprint - with size/time chips where relevant.

POINTS INCLUDED 選穴 (v30)
  Settings, directly under Learn order: a per-point picker. Every channel is
  listed with its point count (e.g. "Lung 11/11"); tap a channel to expand the
  full list and tick or untick individual points. Each row shows the code,
  pinyin, English name and clinical tier.
  - Per channel: All / None buttons.
  - Overall: "Include all" and "Essential only" (keeps just the 54 tier-1
    points - useful for exam cramming, and fully reversible).
  - An unticked point vanishes from every session, every mode and every due
    count, but its review history is KEPT, so ticking it back resumes the
    schedule rather than restarting it.
  - Composes with the existing channel and tier filters, and with archiving.
  - Exclusions ride along in backups, and the Study material summary reports
    them ("12 points excluded").
  Fixed alongside: the header "due" count and per-mode due counts read the
  schedule directly and ignored scope filters, so excluded/filtered points
  still inflated the numbers. They now respect scope.

STRUGGLING CARDS 頑固 (v31) — the leech drill
  A card becomes a "leech" after 4 lapses (4 times you graduated it to review
  and then hit Again). Previously the flag did almost nothing.
  NEW SESSION: "Struggling Cards" appears on the home screen ONLY when you have
  some, showing how many. It shows each card ANSWER-FIRST with its lapse count,
  then tests it - re-testing a card the same way it keeps failing is what has
  not been working. The ⊘ archive button is right there if a card is simply bad.
  Leech cards now carry a 頑 marker in the session header wherever they appear.
  REHABILITATION (new): hold a leech for a 3-week interval and the flag lifts;
    its lapse count drops to just under threshold, so one further slip re-flags
    it. Previously "once a leech, always a leech" - the flag could never clear.
  FIXED: due cards were sorted leech-first and then RESHUFFLED, which undid the
    sort completely (leeches landed at positions 37, 14, 26 of 40 in testing).
    Review Only now genuinely leads with them.
  Leeches respect archiving and the point/channel/tier filters, and multi-step
  cases are excluded from the drill (they cannot render answer-first).
